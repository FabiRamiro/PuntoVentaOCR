package com.pos.puntoventaocr;

/**
 * Clase Launcher para evitar problemas con JavaFX cuando se ejecuta desde JAR
 */
public class Launcher {
    public static void main(String[] args) {
        Main.main(args);
    }
}
